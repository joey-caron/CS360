package com.zybooks.inventoryapp;

import android.app.Activity;

public class MainActivity extends Activity {
    // TODO: implement MainActivity
}
