package com.zybooks.inventoryapp;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.zybooks.inventoryapp.model.Item;

import java.util.List;

// dao interface for interfacing with the item database
@Dao
public interface InvDao {

    // allowing the insert of the same item multiple times by passing a
    // conflict resolution strategy
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Item item);

    @Query("DELETE FROM inventory")
    void deleteAll();

    @Query("SELECT * FROM inventory ORDER BY item_count ASC")
    LiveData<List<Item>> getAlphabetizedItems();
}
