package com.zybooks.inventoryapp.model;

// model for users in the login database
public class User {

    String user = null;
    String pass = null;

    public void setUsername(String username) {
        user = username;
    }
    public void setPassword(String password) {
        pass = password;
    }
    public String getUsername() {
        return user;
    }
    public String getPassword() {
        return pass;
    }

}
