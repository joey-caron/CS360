package com.zybooks.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.inventoryapp.model.Item;

import com.zybooks.inventoryapp.database.InventoryDatabase;

// class for adding items to the database
public class AddActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        InventoryDatabase inventoryHelper = new InventoryDatabase(this) {
            @Override
            public InvDao invDao() {
                return null;
            }
        };
        EditText etName = (EditText) findViewById(R.id.etName);
        EditText etQty = (EditText) findViewById(R.id.etQty);
        EditText etDescription = (EditText) findViewById(R.id.etDescription);
        Button addButton = (Button) findViewById(R.id.addButton);
        Button updButton = (Button) findViewById(R.id.updButton);

        // onclick listener to make action happen with the button is pressed
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String quantity = etQty.getText().toString();
                int count = Integer.parseInt(quantity);
                String desc = etDescription.getText().toString();
                Item item = new Item(name, count, desc);
                boolean exists = inventoryHelper.checkItem(name);
                if (exists) {
                    Toast.makeText(AddActivity.this, "Item already exists", Toast.LENGTH_SHORT).show();
                } else {
                    inventoryHelper.addItem(item);
                    Intent inn3 = new Intent(AddActivity.this, MainActivity.class);
                    startActivity(inn3);
                }
            }
        });
        // another button click listener to make things happen when button is pressed
        updButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String quantity = etQty.getText().toString();
                int count = Integer.parseInt(quantity);
                String desc = etDescription.getText().toString();
                boolean exists = inventoryHelper.checkItem(name);
                if (!exists) {
                    Toast.makeText(AddActivity.this, "Item does not exist", Toast.LENGTH_SHORT).show();
                }
                else {
                    inventoryHelper.updateItem(name, count, desc);
                    Intent inn4 = new Intent(AddActivity.this, MainActivity.class);
                    startActivity(inn4);
                }
            }
        });
    }
}
