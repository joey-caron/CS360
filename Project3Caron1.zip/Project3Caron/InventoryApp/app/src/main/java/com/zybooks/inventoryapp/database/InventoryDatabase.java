package com.zybooks.inventoryapp.database;




import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.room.Database;

import com.zybooks.inventoryapp.InvDao;
import com.zybooks.inventoryapp.model.Item;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

// database to hold inventory
@Database(entities = {Item.class}, version = 1)
public abstract class InventoryDatabase extends SQLiteOpenHelper {

    public abstract InvDao invDao();
    private static final String DATABASE_NAME = "Stock";
    public static final String TABLE_INVENTORY = "inventory";
    private static final String COLUMN_ITEM_NAME = "item_name";
    private static final String COLUMN_ITEM_COUNT = "item_count";
    private static final String COLUMN_ITEM_DESC = "item_desc";
    private static final int DATABASE_VERSION = 1;
    private static volatile InventoryDatabase INSTANCE;
    private static final int NUMBER_OF_THREADS = 4;
    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    //order to create table
    private final String INVENTORY_TABLE =
            "CREATE TABLE " + TABLE_INVENTORY + "("
            + COLUMN_ITEM_NAME + " TEXT PRIMARY KEY,"
            + COLUMN_ITEM_COUNT + " INTEGER,"
            + COLUMN_ITEM_DESC + " TEXT" + ")";

    private final String DROP_INVENTORY_TABLE =
            "DROP TABLE IF EXISTS " + TABLE_INVENTORY;

    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(INVENTORY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DROP_INVENTORY_TABLE);
        onCreate(db);
    }

    // method to add an item
    public void addItem(Item item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_NAME, item.getName());
        values.put(COLUMN_ITEM_COUNT, item.getCount());
        values.put(COLUMN_ITEM_DESC, item.getDesc());

        db.insert(TABLE_INVENTORY, null, values);
        db.close();
    }

    // method to update an item
    public void updateItem(String itemName, int count, String desc) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_COUNT, count);
        values.put(COLUMN_ITEM_DESC, desc);
        db.update(TABLE_INVENTORY, values,"ID=?",new String[] {itemName});
        db.close();
    }

    public void delete(String itemName){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        db.delete(TABLE_INVENTORY,"ID=?",new String[]{itemName});
        db.close();
    }

    public int findCount(String itemName) {
        String[] columns = {COLUMN_ITEM_NAME, COLUMN_ITEM_COUNT};
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_ITEM_NAME + " = ?";
        String[] selectionArgs = {itemName};

        Cursor cursor = db.query(
                TABLE_INVENTORY,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null);
        int count = cursor.getInt(1);
        cursor.close();
        db.close();
        return count;

    }

    public String findDesc(String itemName) {
        String[] columns = {COLUMN_ITEM_NAME, COLUMN_ITEM_DESC};
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_ITEM_NAME + " = ?";
        String[] selectionArgs = {itemName};

        Cursor cursor = db.query(
                TABLE_INVENTORY,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null);
        String desc = cursor.getString(2);
        cursor.close();
        db.close();
        return desc;

    }

    public static InventoryDatabase getDatabase(final Context context) {
        return INSTANCE;
    }

    public boolean checkItem(String itemName) {
        String[] columns = {COLUMN_ITEM_NAME};
        SQLiteDatabase db = this.getReadableDatabase();

        String selection = COLUMN_ITEM_NAME + " = ?";
        String[] selectionArgs = {itemName};

        Cursor cursor = db.query(
                TABLE_INVENTORY,
                columns,
                selection,
                selectionArgs,
                null,
                null,
                null
        );
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        return cursorCount > 0;
    }



}