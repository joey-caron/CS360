package com.zybooks.inventoryapp.model;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.zybooks.inventoryapp.ItemRepository;

import java.util.List;

// itemview for sending item view data to the repository
public class ItemView extends AndroidViewModel {

    private ItemRepository mRepository;

    private final LiveData<List<Item>> mAllItems;

    public ItemView (Application application) {
        super(application);
        mRepository = new ItemRepository(application);
        mAllItems = mRepository.getAllItems();
    }

    LiveData<List<Item>> getAllItems() { return mAllItems; }

    public void insert(Item item) { mRepository.insert(item); }
}