package com.zybooks.inventoryapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

// view holder for the items in screen
class ItemViewHolder extends RecyclerView.ViewHolder {
    private final TextView ItemView;

    private ItemViewHolder(View itemView) {
        super(itemView);
        ItemView = itemView.findViewById(R.id.itemName);
    }

    public void bind(String text) {
        ItemView.setText(text);
    }

    static ItemViewHolder create(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.recycler_view, parent, false);
        return new ItemViewHolder(view);
    }
}