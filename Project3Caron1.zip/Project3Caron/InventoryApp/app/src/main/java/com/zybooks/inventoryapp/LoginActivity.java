package com.zybooks.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import android.text.TextWatcher;
import android.text.Editable;
import androidx.appcompat.app.AppCompatActivity;
import com.zybooks.inventoryapp.database.DatabaseHelper;
import com.zybooks.inventoryapp.model.User;
import android.widget.Button;
import android.widget.EditText;
import android.view.View;


public class LoginActivity extends AppCompatActivity {
    private DatabaseHelper databaseHelper;
    EditText user;
    EditText pass;
    private Button log;
    private Button add;
    private Button settings;

    // main screen on app bootup, will allow users to login
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
                databaseHelper = new DatabaseHelper(this);
        user = findViewById(R.id.etText);
        pass = findViewById(R.id.etPassword);
        log = findViewById(R.id.bLog);
        add = findViewById(R.id.bAdd);
        settings = findViewById(R.id.bSetting);
        logListener();
        addListener();
        settingListener();
        //listener to make login or add buttons not work until a password is entered
        pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                log.setEnabled(s.length() != 0);
                add.setEnabled(s.length() != 0);

            }
            @Override
            public void afterTextChanged(Editable s) {

            }
        });


    }



    // an on click listener to make things happen when the login button is pressed
    private void logListener() {
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (databaseHelper.checkUser(user.getText().toString().trim(), pass.getText().toString().trim())) {
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(LoginActivity.this, "Incorrect Username or Password, try again", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    // an on click listener to make things happen when the add user button is pressed
    private void addListener() {
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!databaseHelper.checkUser(user.getText().toString().trim())) {
                    User nUser = new User();
                    nUser.setUsername(user.getText().toString().trim());
                    nUser.setPassword(pass.getText().toString().trim());
                    databaseHelper.addUser(nUser);
                    Toast.makeText(LoginActivity.this, "User created successfully", Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(LoginActivity.this, "User already exists", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    // an on click listener to make things happen when the setting button is pressed
    private void settingListener() {
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentS = new Intent(LoginActivity.this, SettingActivity.class);
                startActivity(intentS);

            }
        });
    }



}
