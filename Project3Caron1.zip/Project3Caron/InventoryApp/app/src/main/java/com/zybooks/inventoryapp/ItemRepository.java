package com.zybooks.inventoryapp;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.zybooks.inventoryapp.database.InventoryDatabase;
import com.zybooks.inventoryapp.model.Item;

import java.util.List;

public class ItemRepository {

    private InvDao mInvDao;
    private LiveData<List<Item>> mAllItems;


    // repository for ease of accessing the inventory database data
    public ItemRepository(Application application) {
        InventoryDatabase db = InventoryDatabase.getDatabase(application);
        mInvDao = db.invDao();
        mAllItems = mInvDao.getAlphabetizedItems();
    }


    // method to get all items from the database
    public LiveData<List<Item>> getAllItems() {
        return mAllItems;
    }

    // method to insert item into database
    public void insert(Item item) {
        InventoryDatabase.databaseWriteExecutor.execute(() -> {
            mInvDao.insert(item);
        });
    }
}
