package com.zybooks.inventoryapp;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class SettingActivity extends AppCompatActivity {
    public String phone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        TextView tvPhone = (TextView) findViewById(R.id.tvPhone);
        EditText etPhone = (EditText) findViewById(R.id.etPhone);
        Button bSms = (Button) findViewById(R.id.bSms);
        Button back = (Button) findViewById(R.id.back);
        // text change listener so the allow button will not work until a 10 digit phone number has been enetered
        etPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                bSms.setEnabled(s.length() == 10);


            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        // on click listener for the allow permission button
        bSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                phone = etPhone.getText().toString().trim();
                setPermission();
            }
        });

        // on click listener for the back button to return to the login screen
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SettingActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

    }
    // a method to make the allow sms permission box to pop up
    private void setPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
    }
}
