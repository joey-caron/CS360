package com.zybooks.inventoryapp;


import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.inventoryapp.database.InventoryDatabase;
import com.zybooks.inventoryapp.model.Item;


import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {


    RecyclerView recyclerView;
    InventoryDatabase inventoryHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = findViewById(R.id.recyclerView);
        final ItemListAdapter adapter = new ItemListAdapter(new ItemListAdapter.ItemDiff());
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        TextView header1 = (TextView) findViewById(R.id.header1);
        TextView header2 = (TextView) findViewById(R.id.header2);
        TextView header3 = (TextView) findViewById(R.id.header3);
        Button invButton = (Button) findViewById(R.id.invButton);
        // initializing all variables and an inventory database
        inventoryHelper = new InventoryDatabase(this) {
            @Override
            public InvDao invDao() {
                return null;
            }
        };

        // on click listener to move to the add item page
        invButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent inn2 = new Intent(MainActivity.this, AddActivity.class);
                startActivity(inn2);
            }
        });



    }

    // method for sending low stock sms alerts
    public void sendSMS() {
        int permissionSMS = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        SmsManager smsManager = SmsManager.getDefault();
        SettingActivity settings = new SettingActivity();
        if (permissionSMS == PackageManager.PERMISSION_GRANTED) {
            smsManager.sendTextMessage(settings.phone, null, "Stock low", null, null);
        }
        else {
            return;
        }
    }



    // method to access the database to populate on screen
    private List<Item> getList() {
        List<Item> items = new ArrayList<>();
        String query = "SELECT * FROM " + InventoryDatabase.TABLE_INVENTORY;
        SQLiteDatabase db = this.inventoryHelper.getReadableDatabase();
        try {
            Cursor cursor = db.rawQuery(query, null);
            try {
                if (cursor.moveToFirst()) {
                    do {
                        Item newItem = new Item();
                        newItem.setName(cursor.getString(0));
                        newItem.setCount(cursor.getInt(1));
                        items.add(newItem);
                    } while (cursor.moveToNext());
                }
            } finally {
                try {
                    cursor.close();
                } catch (Exception ignore) {
                }
            }
        } finally {
            try {
                db.close();
            } catch (Exception ignore) {
            }
        }
        return items;
    }
}