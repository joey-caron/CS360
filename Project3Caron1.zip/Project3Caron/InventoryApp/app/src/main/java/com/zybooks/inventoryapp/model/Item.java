package com.zybooks.inventoryapp.model;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

// model for items that will populate the inventory database
@Entity(tableName = "inventory")
public class Item {

    @PrimaryKey
    @ColumnInfo(name = "item_name")
    String itemName = null;
    @ColumnInfo(name = "item_count")
    int count = 0;
    @ColumnInfo(name = "item_desc")
    String desc = null;

    public Item() {
        String itemName;
        int Count;
        String desc;
    }
    public Item(String itemName, int Count, String Desc) {
        itemName = itemName;
        count = Count;
        desc = Desc;
    }


    public void setName(String itemName) {
        itemName = itemName;
    }

    public void setCount(int itemCount) {
        count = itemCount;
    }

    public void setDesc(String itemDesc) {
        desc = itemDesc;
    }



    public String getName() {
        return itemName;
    }

    public int getCount() {
        return count;
    }

    public String getDesc() {
        return desc;
    }
}
